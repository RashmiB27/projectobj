
package com.java;


	

public class users 
{
		
		private int userId ;
	    
		private String Username;
		private String email ;
		private int mobileno;
		private String address;
		private String bankname;
		private int bankaccountno;
		private int IFSC_code;
		private int itemspurchased;
		private String status;
		
		
		
		public String getStatus() {
			return status;
		}
		public void setStatus(String status) {
			this.status = status;
		}
		public int getItemspurchased() {
			return itemspurchased;
		}
		public void setItemspurchased(int itemspurchased) {
			this.itemspurchased = itemspurchased;
		}
		public int getUserId() {
			return userId;
		}
		public void setUserId(int userId) {
			this.userId = userId;
		}
		public String getUsername() {
			return Username;
		}
		public void setUsername(String username) {
			Username = username;
		}
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		public int getMobileno() {
			return mobileno;
		}
		public void setMobileno(int mobileno) {
			this.mobileno = mobileno;
		}
		public String getAddress() {
			return address;
		}
		public void setAddress(String address) {
			this.address = address;
		}
		public String getBankname() {
			return bankname;
		}
		public void setBankname(String bankname) {
			this.bankname = bankname;
		}
		public int getBankaccountno() {
			return bankaccountno;
		}
		public void setBankaccountno(int bankaccountno) {
			this.bankaccountno = bankaccountno;
		}
		public int getIFSC_code() {
			return IFSC_code;
		}
		public void setIFSC_code(int iFSC_code) {
			IFSC_code = iFSC_code;
		}
		
}

