package com.java;

import java.util.ArrayList;
import java.util.Currency;
import java.util.List;

import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;




@Path("/currency")


public class currencyservice {

	static List<currency> currlist = new ArrayList<currency>();

	
		
		
		static {
		currency curr1 = new currency();
		
		curr1.setCurrentId(2);
		curr1.setSourcecurrency("USD");
		curr1.setTargetcurrency("INR");
		curr1.setAmounttoconvert(500);
		
	    currency curr2 = new currency();
		
		curr2.setCurrentId(3);
		curr2.setSourcecurrency("USD");
		curr2.setTargetcurrency("INR");
		curr2.setAmounttoconvert(500);
		
		
		
		currlist.add(curr1);
		currlist.add(curr2);
		System.out.println("currency service is called().......");
		
		
	}
	
		public currencyservice() {
			System.out.println("New Object created");
		}

		@DELETE
		@Path("/delete/{cid}")
		public String deleteIt(@PathParam("cid") int x)
		{
			boolean found = false;
			currency curr=null;
			for(currency currency : currlist)
				{
				if(currency.getCurrentId()==x)
				{
					curr=currency;
					currlist.remove(curr);
					found=true;
					break;
				}
				}
			if(found ==true)
				return "currency deleted";
			else
				return "currency not found : "+x;
	}
	
		
		@POST
		@Path("/add")
		public String addIt(currency currobj)
		{
			boolean found = false;
			currency curr = null;
			for(currency currency : currlist)
			{
				if(currency.getCurrentId()==currobj.getCurrentId())
				{
					found = true;
					break;
				}
			}
			if(found==true)
				return "currency already exists";
			else
			{
				currlist.add(currobj);
				return "currency added";
			}
			
		}
	

		@PUT
		@Path("/update")
		public String updateIt(currency currobj)
		{
			boolean found = false;
			currency curr = null;
			for(currency currency : currlist)
			{
				if(currency.getCurrentId()==currobj.getCurrentId())
				{
					found = true;
					currlist.remove(currency);
					break;
				}
			}
			if(found==true)
			{
				currlist.add(currobj);
				return "currency modified";
			}
			else
			{
				return "currency not found";
			}
					
			
			
		}
	
		

	/*
	 * @GET
	 * 
	 * @Path("/convert")
	 * 
	 * @Produces(MediaType.APPLICATION_JSON)
	 * 
	 * public currency convertIt() {
	 * 
	 * 
	 * 
	 * currency curr = new currency();
	 * 
	 * curr.setCurrentId(1); curr.setSourcecurrency("USD");
	 * curr.setTargetcurrency("INR"); curr.setAmounttoconvert(500); return curr; }
	 */
@GET
@Path("/converts")
@Produces(MediaType.APPLICATION_JSON)

public List<currency>convertall()
{
	

	
	return currlist ;


}

@GET
@Path("/convert/{cid}")
@Produces(MediaType.APPLICATION_JSON)
public currency convertIt (@PathParam("cid")int x)
{
	currency curr=null;
	for(currency currency : currlist)
	{
		if(currency.getCurrentId()==x)
		{
			curr = currency;
		}
	}
	return curr;
}


/*public String welcome()
{
	System.out.println("hello everyone........");
	return "<h1>hiiiiiiii</h1>";*/
}

