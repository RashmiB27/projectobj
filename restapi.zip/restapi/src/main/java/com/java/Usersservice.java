package com.java;

import java.util.ArrayList;
import java.util.Currency;
import java.util.List;

import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;




@Path("/user")


public class Usersservice {

	static List<users> userlist = new ArrayList<users>();

	
		
		
		static {
		users u1 = new users();
		
		u1.setUserId(1);
		u1.setUsername("john");
		u1.setEmail("john@gmail.com");
		u1.setMobileno(1234567890);
		u1.setAddress("abc");
		u1.setBankname("HDFC");
		u1.setBankaccountno(345347345);
		u1.setIFSC_code(56247);
		u1.setItemspurchased(3);
		u1.setStatus("Active");
		
	    users u2 = new users();
		
	    u2.setUserId(2);
		u2.setUsername("lily");
		u2.setEmail("lily@gmail.com");
		u2.setMobileno(1234567890);
		u2.setAddress("mno");
		u2.setBankname("HDFC");
		u2.setBankaccountno(345347345);
		u2.setIFSC_code(56247);
		u2.setItemspurchased(5);
		u2.setStatus("deactive");
		
		
		
		userlist.add(u1);
		userlist.add(u2);
	
		
		
	}
	
		public Usersservice() {
			System.out.println("method is called");
		}

		@DELETE
		@Path("/delete/{cid}")
		public String deleteIt(@PathParam("cid") int x)
		{
			boolean found = false;
			users user=null;
			for(users user1 : userlist)
				{
				if(user1.getUserId()==x)
				{
					users user2 = user1;
					userlist.remove(user2);
					found=true;
					break;
				}
				}
			if(found ==true)
				return "user deleted";
			else
				return "user not found : "+x;
	}
	
		
		@POST
		@Path("/add")
		public String addIt(users userobj)
		{
			boolean found = false;
			users user = null;
			for(users user1 : userlist)
			{
				if(user1.getUserId()==userobj.getUserId())
				{
					found = true;
					break;
				}
			}
			if(found==true)
				return "user already exists";
			else
			{
				userlist.add(userobj);
				return "user added";
			}
			
		}
	

		@PUT
		@Path("/update")
		public String updateIt(users userobj)
		{
			boolean found = false;
			users user = null;
			for(users user1 : userlist)
			{
				if(user1.getUserId()==userobj.getUserId())
				{
					found = true;
					userlist.remove(user1);
					break;
				}
			}
			if(found==true)
			{
				userlist.add(userobj);
				return "user modified";
			}
			else
			{
				return "user not found";
			}
					
			
			
		}
	
		


@GET
@Path("/alluser")
@Produces(MediaType.APPLICATION_JSON)

public List<users>convertall()
{
	

	
	return userlist ;


}

@GET
@Path("/user/{cid}")
@Produces(MediaType.APPLICATION_JSON)
public users convertIt (@PathParam("cid")int x)
{
	users user=null;
	for(users user1 : userlist)
	{
		if(user1.getUserId()==x)
		{
			user = user1;
		}
	}
	return user;
}


/*public String welcome()
{
	System.out.println("hello everyone........");
	return "<h1>hiiiiiiii</h1>";*/
}

