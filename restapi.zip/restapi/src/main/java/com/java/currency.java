package com.java;

public class currency {
	
	private int currentId ;
	private String sourcecurrency;
	private String targetcurrency;
	private float amounttoconvert;
	
	public int getCurrentId() {
		return currentId;
	}
	public void setCurrentId(int currentId) {
		this.currentId = currentId;
	}
	public String getSourcecurrency() {
		return sourcecurrency;
	}
	public void setSourcecurrency(String sourcecurrency) {
		this.sourcecurrency = sourcecurrency;
	}
	public String getTargetcurrency() {
		return targetcurrency;
	}
	public void setTargetcurrency(String targetcurrency) {
		this.targetcurrency = targetcurrency;
	}

	
	public float getAmounttoconvert() {
		return amounttoconvert;
	}
	public void setAmounttoconvert(float amounttoconvert) {
		this.amounttoconvert = amounttoconvert;
	}
	
	
	

}
