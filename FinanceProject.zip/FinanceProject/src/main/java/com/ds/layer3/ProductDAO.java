package com.ds.layer3;

import java.util.List;

import com.ds.layer2.OrderDetails;
import com.ds.layer2.Product;

public interface ProductDAO {

	
	Product selectProduct(int productId);
	List<Product> selectAllProducts();
	
	void insertProduct(Product product1);
	void updateOrder(Product product1);
	void deleteOrder(int productId);
}
