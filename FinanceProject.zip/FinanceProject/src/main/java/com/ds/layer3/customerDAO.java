package com.ds.layer3;

import java.util.List;

import com.ds.layer2.Customer;

public interface customerDAO {
	
	Customer selectCustomer(int customerId);
	List<Customer> selectAllCustomers();
	
	void insertCustomer(Customer customer1);
	void updateCustomer(Customer customer1);
	void deleteCustomer(int customerId);
	

}
