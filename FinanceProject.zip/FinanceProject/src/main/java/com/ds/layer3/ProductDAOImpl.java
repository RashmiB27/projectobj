package com.ds.layer3;

import java.util.List;

import com.ds.layer2.Product;

public class ProductDAOImpl implements ProductDAO{

	@Override
	public Product selectProduct(int productId) {
		// TODO Auto-generated method stub
		
		
		return null;
	}

	@Override
	public List<Product> selectAllProducts() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void insertProduct(Product product1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateOrder(Product product1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteOrder(int productId) {
		// TODO Auto-generated method stub
		
	}

}
