package com.ds.layer5;


import java.util.List;

import javax.servlet.http.HttpSession;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.ds.layer2.Customer;
import com.ds.layer2.EMICard;
import com.ds.layer2.Product;
import com.ds.layer4.CustomerAlreadyPresentException;
import com.ds.layer4.CustomerNotEligibleException;
import com.ds.layer4.CustomerNotFoundException;
import com.ds.layer4.EMICardService;
import com.ds.layer4.EMICardServiceImpl;
import com.ds.layer4.InsufficientCreditLimitException;
import com.ds.layer4.OrderDetailsService;
import com.ds.layer4.OrderDetailsServiceImpl;
import com.ds.layer4.ProductAlreadyExistsException;
import com.ds.layer4.ProductNotFoundException;
import com.ds.layer4.ProductService;
import com.ds.layer4.ProductServiceImpl;
import com.ds.layer4.UserService;
import com.ds.layer4.UserServiceImpl;





@Path("/finance")
public class FinanceController {

	ProductService prodservice;
	UserService userservice;
	
	HttpSession session;
	EMICardService emiCardService;
	OrderDetailsService orderService;
	
	public FinanceController() {
		this.prodservice =  new ProductServiceImpl();
		this.userservice = new UserServiceImpl();
		emiCardService = new EMICardServiceImpl();
		orderService = new OrderDetailsServiceImpl();
	}

	//addproduct
	@POST
	@Path("/addproduct")
	public Response addproduct(Product product1) 
	{
		try
		{
			prodservice.AddProductService(product1);
			return  Response
					.status(Response.Status.OK)
					.entity("record added successfully")
					.build();
		}catch(ProductAlreadyExistsException e)
		{
			return  Response
					.status(Response.Status.NOT_FOUND)
					.entity(e.getMessage())
					.build();
		}
	}
	
	//adduser
	
	@POST
	@Path("/adduser")
	public Response adduser(Customer customer1) throws  CustomerNotEligibleException, CustomerAlreadyPresentException 
	{
		userservice.ApproveUser(customer1);
		return   Response
				.status(Response.Status.OK)
				.entity("user added succcessfully")
				.build();
	}
	
	@GET
	@Path("/login")
	public Response login(String userName , String Password)
	{
		userservice.login(userName,Password);
		return   Response
				.status(Response.Status.OK)
				.entity("logged in")
				.build();
	}
	
	
	@GET
	@Path("/getproducts")
	@Produces(MediaType.APPLICATION_JSON)
	public Response all() {	
		
		return  Response
				.status(Response.Status.OK)
				.entity(prodservice.Viewallproducts())
				.build();
	}
	
	@GET
	@Path("/getusers")
	@Produces(MediaType.APPLICATION_JSON)
	public Response alluser() {	
		
		return  Response
				.status(Response.Status.OK)
				.entity(userservice.Viewalluser())
				.build();
	}
	
	@GET
	@Path("/greet")

	public String greet() {	
		
		return "<h1>hii</h1>";
	}
	
	//edit product
	@PUT
	@Path("/editproduct")
	public String modifyIt(Product product1) {
		
		try {
			prodservice.EditProduct(product1);
			return "product modified successfully";

		} catch (ProductNotFoundException e) {
			return e.getMessage();
		}
	}
	
	//edit user
	@PUT
	@Path("/edituser")
	public String modifyuser(Customer customer1) throws  CustomerNotFoundException {
		
		userservice.ModifyUser(customer1);
		return "user modified successfully";
	}
	
	@GET
	@Path("/getproduct/{cid}")
	@Produces(MediaType.APPLICATION_JSON)
	public Product single(@PathParam("cid") int x) throws ProductNotFoundException
	{
		return prodservice.viewsingleproduct(x);
	}
	
	@DELETE 
	@Path("/deleteproduct/{cid}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response deleteproduct(@PathParam("cid") int x) throws ProductNotFoundException
	{
		prodservice.RemoveProduct(x);
		return  Response
				.status(Response.Status.OK)
				.entity("delete")
				.build();
		}
	
	
	@GET
	@Path ("/viewEMICard")
	@Produces(MediaType.APPLICATION_JSON)
	public EMICard viewEMICard(){
		int customerId = (int) session.getAttribute("customerId");
		return emiCardService.viewEMICard(customerId);
	}
	
	@POST
	@Path ("/placeOrder/{pid}/{emiPeriod}")										//To get form parameter ==> @FormParam
	public Response confirmOrder(@PathParam("pid") int productId, @PathParam("emiPeriod") int emiPeriod) {
		try {
			int customerId = (int) session.getAttribute("customerId");
			orderService.placeOrder(emiPeriod, customerId, productId);
			return Response.status(Response.Status.OK).entity("Order Placed Successfully.").build();
		} catch (InsufficientCreditLimitException e) {
			return Response.status(Response.Status.NOT_ACCEPTABLE).entity(e.getMessage()).build();
		}
	}
}
