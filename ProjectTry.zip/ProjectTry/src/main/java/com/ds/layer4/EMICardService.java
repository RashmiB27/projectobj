package com.ds.layer4;

import java.util.List;

import com.ds.layer2.EMICard;

public interface EMICardService {
	void grantEMICardService(int customerId, String cardType);
	void revokeEMICardService(int customerId);
	void updateEMICardService(EMICard emiCard);
	EMICard viewEMICard(int customerId);
	List<EMICard> viewAllEMICards();
}
