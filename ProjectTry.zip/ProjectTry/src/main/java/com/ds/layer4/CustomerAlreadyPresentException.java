package com.ds.layer4;

public class CustomerAlreadyPresentException extends Exception {

	public CustomerAlreadyPresentException(String Message) {
		super(Message);
		// TODO Auto-generated constructor stub
	}

	

	
}
