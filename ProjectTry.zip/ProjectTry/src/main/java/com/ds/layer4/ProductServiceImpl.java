package com.ds.layer4;

import java.util.List;




import com.ds.layer2.Product;
import com.ds.layer3.ProductDAO;
import com.ds.layer3.ProductDAOImpl;


public class ProductServiceImpl implements ProductService{

	ProductDAO productdao;
	
	public ProductServiceImpl() {

		this.productdao =  new ProductDAOImpl();
	}
	
	@Override
	public void AddProductService(Product product1) throws ProductAlreadyExistsException {
		// TODO Auto-generated method stub
		List<Product> allproduct = productdao.selectAllProducts();
		boolean productFound=false;	
		for (Product product : allproduct) {
			if(product.getProductName().equals(product1.getProductName()) && (product.getProductPrice()==product1.getProductPrice()))
			{
					productFound=true;	
					break;
			}
		}
		
		if(productFound==true)
			throw new ProductAlreadyExistsException("Product is alreaydy present");
		else
			productdao.insertProduct(product1);
		
	}

	@Override
	public void EditProduct(Product Product1) throws ProductNotFoundException {
		// TODO Auto-generated method stub
		List<Product> allproduct = productdao.selectAllProducts();
		boolean productFound=false;	
		for (Product product : allproduct) {
			if(product.getProductId()==Product1.getProductId())
			{
					productFound=true;	
					break;
			}
		}
		
		if(productFound==false)
			throw new ProductNotFoundException("Customer is alreaydy present");
		else
			productdao.updateProduct(Product1);
		
	}

	@Override
	public List<Product> Viewallproducts() {
		return productdao.selectAllProducts();
	}

	@Override
	public Product viewsingleproduct(int ProductId) {
		// TODO Auto-generated method stub
		return productdao.selectProduct(ProductId);
	}

	@Override
	public void RemoveProduct(int ProductId) throws ProductNotFoundException {
		// TODO Auto-generated method stub
		
		List<Product> allproduct = productdao.selectAllProducts();
		boolean productFound=false;	
		for (Product product : allproduct) {
			if(product.getProductId()==ProductId)
			{
					productFound=true;	
					break;
			}
		}
		
		if(productFound==false)
			throw new ProductNotFoundException("Not Found");
		else
			productdao.deleteProduct(ProductId);
		
	}

}
