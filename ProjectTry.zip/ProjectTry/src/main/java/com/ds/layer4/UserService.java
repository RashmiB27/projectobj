package com.ds.layer4;

import com.ds.layer4.CustomerNotEligibleException;


import java.util.List;

import com.ds.layer2.Customer;


public interface UserService {
	
	void ApproveUser(Customer customer1) throws CustomerNotEligibleException, CustomerAlreadyPresentException;

	void ModifyUser(Customer customer1) throws CustomerNotFoundException;
	
}
