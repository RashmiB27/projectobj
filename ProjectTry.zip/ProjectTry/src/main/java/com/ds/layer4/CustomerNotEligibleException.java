package com.ds.layer4;

public class CustomerNotEligibleException extends Exception {

	public CustomerNotEligibleException(String msg) {
		super(msg);
		// TODO Auto-generated constructor stub
	}
	
	
	

}
