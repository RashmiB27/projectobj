package com.ds.layer4;

import java.util.List;


import com.ds.layer2.Customer;
import com.ds.layer3.CustomerDAO;
import com.ds.layer3.CustomerDAOImpl;


public class UserServiceImpl implements UserService {

	CustomerDAO customerdao;
	
	
	
	public UserServiceImpl() {
		customerdao = new CustomerDAOImpl();
	}



	@Override
	public void ApproveUser(Customer customer1) throws CustomerNotEligibleException,CustomerAlreadyPresentException {
		// TODO Auto-generated method stub
		
		List<Customer> alluser = customerdao.selectAllCustomers();
		boolean customerFound=false;	
		for (Customer customer : alluser) {
			if(customer.getPhoneNo()==customer1.getPhoneNo()) {
					customerFound=true;	
					break;
			} 
		}
		
		int age1 = customer1.getAge();
		int salary1 = customer1.getSalary();
		
		if(customerFound==true)
			throw new CustomerAlreadyPresentException("Customer is alreaydy present");
		else if(age1<20 || salary1<20000)
			throw new CustomerNotEligibleException("Customer is Not Eligible");
		else
			customerdao.insertCustomer(customer1);
	}

	

	@Override
	public void ModifyUser(Customer customer1) throws CustomerNotFoundException {
		// TODO Auto-generated method stub
		
		List<Customer> alluser = customerdao.selectAllCustomers();
		boolean customerFound=false;	
		for (Customer customer : alluser) {
			if(customer.getCustomerId()==customer1.getCustomerId()) {
					customerFound=true;	
					break;
			} 
		}
		if(customerFound==false)
			throw new CustomerNotFoundException("Customer not found exception");
		else 
			customerdao.updateCustomer(customer1);
		
	}

}
