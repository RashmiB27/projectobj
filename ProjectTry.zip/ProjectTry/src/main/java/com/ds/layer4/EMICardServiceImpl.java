package com.ds.layer4;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

import com.ds.layer2.EMICard;
import com.ds.layer3.EMICardDAO;
import com.ds.layer3.EMICardDAOImpl;

public class EMICardServiceImpl implements EMICardService {
	EMICardDAO emiDao;
	
	public EMICardServiceImpl() {
		emiDao = new EMICardDAOImpl();
	}
	
	@Override
	public void grantEMICardService(int customerId, String cardType){	
		EMICard card = new EMICard();
		card.setCardIssueDate(Date.valueOf(LocalDate.now()));
		card.setCustomerId(customerId);
		card.setValidityYears(2);
		card.setCardType(cardType);
		if(cardType=="Gold") {
			card.setRemainingCredit(50000);
		}
		else {
			card.setRemainingCredit(100000);
		}
			
		emiDao.insertEMICard(card);
	}

	@Override
	public void revokeEMICardService(int customerId) {
		List<EMICard> cards = emiDao.selectAllEMICards();
		
		for(EMICard card:cards) {
			if(card.getCustomerId()==customerId) {
				emiDao.deleteEMICard(customerId);
				break; 
			}
		}
	}

	@Override
	public void updateEMICardService(EMICard emiCard) {
		List<EMICard> cards = emiDao.selectAllEMICards();
		
		for(EMICard card:cards) {
			if(card.getCustomerId()==emiCard.getCustomerId()) {
				emiDao.updateEMICard(emiCard);
				break; 
			}
		}
	}

	@Override
	public EMICard viewEMICard(int customerId) {
		return emiDao.selectEMICard(customerId);
	}
	
	@Override
	public List<EMICard> viewAllEMICards() {
		return emiDao.selectAllEMICards();
	}
}
