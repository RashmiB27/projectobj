package com.ds.layer4;

public class ProductAlreadyExistsException extends Exception {

	public ProductAlreadyExistsException(String msg) {
		super(msg);
		// TODO Auto-generated constructor stub
	}
	
	

}
