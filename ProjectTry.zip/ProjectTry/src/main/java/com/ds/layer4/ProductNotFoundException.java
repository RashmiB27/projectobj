package com.ds.layer4;

public class ProductNotFoundException extends Exception {

	public ProductNotFoundException(String msg) {
		super(msg);
		// TODO Auto-generated constructor stub
	}
	
	

}
