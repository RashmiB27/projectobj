package com.ds.layer4;


public class CustomerNotFoundException extends Exception {

	public CustomerNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	

}
