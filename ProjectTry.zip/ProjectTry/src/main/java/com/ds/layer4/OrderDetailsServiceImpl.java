package com.ds.layer4;

import java.sql.Date;
import java.time.LocalDate;

import com.ds.layer2.EMICard;
import com.ds.layer2.OrderDetails;
import com.ds.layer2.Product;
import com.ds.layer3.OrderDetailsDAO;
import com.ds.layer3.OrderDetailsDAOImpl;

public class OrderDetailsServiceImpl implements OrderDetailsService {
	OrderDetailsDAO orderDao;
	
	public OrderDetailsServiceImpl() {
		orderDao = new OrderDetailsDAOImpl();
	}
	
	@Override
	public void placeOrder(int emiPeriod,int customerId, int productId) throws InsufficientCreditLimitException{
//		EMICardService emiCardService = new EMICardServiceImpl();
//		ProductDAO productDao = new ProductDAOImpl();
//
//		EMICard card = emiCardService.viewEMICard(customerId);
//		Product product = productDao.selectProduct(productId);
//		
//		int remCredit = card.getRemainingCredit();
//		int productPrice = product.getProductPrice();
//		
//		if(productPrice>remCredit) {
//			throw new InsufficientCreditLimitException("The product price exceeds available credit limit. Current remaining credit limit is "+remCredit+".");
//		}
//		else {
//			OrderDetails order = new OrderDetails();
//			order.setOrderDate(Date.valueOf(LocalDate.now()));
//			order.setEmiPeriod(emiPeriod);
//			order.setCustomerId(customerId);
//			order.setProductId(productId);
//			
//			orderDao.insertOrderDetails(order);
//			
//			remCredit = remCredit-productPrice;
//			card.setRemainingCredit(remCredit);
//			emiCardService.updateEMICardService(card);
//		}
	}

}
