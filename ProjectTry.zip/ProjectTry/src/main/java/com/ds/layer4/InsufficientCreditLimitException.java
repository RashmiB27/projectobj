package com.ds.layer4;

public class InsufficientCreditLimitException extends Exception {
	public InsufficientCreditLimitException(String str) {
		super(str);
	}
}
