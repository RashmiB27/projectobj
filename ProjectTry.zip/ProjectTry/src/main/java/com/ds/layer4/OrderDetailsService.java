package com.ds.layer4;

public interface OrderDetailsService {
	void placeOrder(int emiPeriod,int customerId, int productId) throws InsufficientCreditLimitException;
//	List<OrderDetails> viewCustomerOrderHistory(int customerId);
//	OrderDetails viewAnOrder(int orderId);
//	List<OrderDetails> viewAllCutomersOrderHistory();
}
