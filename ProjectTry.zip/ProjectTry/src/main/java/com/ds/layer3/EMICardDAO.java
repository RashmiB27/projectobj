package com.ds.layer3;

import java.util.List;

import com.ds.layer2.EMICard;

public interface EMICardDAO {   //EMICard Repository

	EMICard selectEMICard(int customerId);
	List<EMICard> selectAllEMICards();
	
	void insertEMICard(EMICard emiCard);
	void updateEMICard(EMICard emiCard);
	void deleteEMICard(int customerId);
}